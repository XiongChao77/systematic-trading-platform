(function () {
  'use strict';
  const data = window.INDICATOR_DECILES;
  const host = document.getElementById('indicator-panels');
  if (!data || !host) return;
  const css = getComputedStyle(document.documentElement);
  const color = name => css.getPropertyValue(name).trim();
  const names = {clustering: '\u6ce2\u52a8\u7387\u805a\u96c6', adx: 'ADX(14)', rsi: 'RSI(14)', wr: 'WR(14)'};
  const labels = ['\u7ec4\u522b', '\u5165\u573a\u503c\u533a\u95f4', '\u5b9e\u9645\u6700\u5c0f\u503c', '\u5b9e\u9645\u6700\u5927\u503c', '\u5e73\u5747\u5165\u573a\u503c', '\u8d77\u70b9\u6570', '\u6837\u672c\u5360\u6bd4', '\u51fb\u7a7f\u6570', '\u672a\u7ed3\u675f', '\u6761\u4ef6\u51fb\u7a7f\u7387'];
  const charts = {};
  const tables = {};
  const titles = {};
  const percent = value => value == null ? '\u65e0\u6837\u672c' : value.toFixed(4) + '%';
  const number = value => value.toLocaleString('en-US');
  const valueText = (value, key) => value == null ? '\u2014' : (value * (key === 'clustering' ? 100 : 1)).toFixed(4) + (key === 'clustering' ? '%' : '');
  Object.keys(names).forEach(key => {
    const panel = document.createElement('div');
    panel.className = 'panel';
    panel.style.marginTop = '22px';
    const title = document.createElement('h3');
    panel.appendChild(title);
    titles[key] = title;
    const figure = document.createElement('figure');
    const chart = document.createElement('div');
    chart.className = 'bucket-chart';
    figure.appendChild(chart);
    panel.appendChild(figure);
    charts[key] = echarts.init(chart, null, {renderer: 'svg'});
    const wrap = document.createElement('div');
    wrap.className = 'table-wrap';
    const table = document.createElement('table');
    const head = table.createTHead().insertRow();
    labels.forEach(label => { const th = document.createElement('th'); th.textContent = label; head.appendChild(th); });
    tables[key] = table.createTBody();
    wrap.appendChild(table);
    panel.appendChild(wrap);
    host.appendChild(panel);
    charts[key].resize();
  });
  function render() {
    const side = document.getElementById('side').value;
    const layers = Number(document.getElementById('layers').value);
    document.getElementById('indicator-meta').textContent = `${data.meta.start} \u2014 ${data.meta.end} | ${number(data.meta.eligible_bars)} \u4e2a\u5171\u540c\u6709\u6548\u8d77\u70b9 | ${side === 'long' ? '\u505a\u591a' : '\u505a\u7a7a'} K${layers}`;
    Object.keys(names).forEach(key => {
      const rows = data.rows.filter(row => row.indicator === key && row.side === side && row.layers === layers);
      titles[key].textContent = `${names[key]} \u00b7 ${side === 'long' ? '\u505a\u591a' : '\u505a\u7a7a'} K${layers} \u00b7 \u5341\u7ec4\u6761\u4ef6\u51fb\u7a7f\u7387`;
      tables[key].replaceChildren();
      rows.forEach(row => {
        const tr = tables[key].insertRow();
        const interval = `${row.group === 1 ? '[' : '('}${valueText(row.lower, key)}, ${valueText(row.upper, key)}]`;
        [String(row.group), interval, valueText(row.entry_min, key), valueText(row.entry_max, key), valueText(row.entry_mean, key), number(row.starts), row.coverage_pct.toFixed(2) + '%', number(row.breaches), number(row.unresolved), percent(row.breach_rate_pct)].forEach(text => { tr.insertCell().textContent = text; });
      });
      charts[key].setOption({
        animation: false,
        color: [color('--accent')],
        grid: {left: 65, right: 30, top: 45, bottom: 45},
        tooltip: {trigger: 'axis', appendToBody: true, formatter: params => {
          const row = rows[params[0].dataIndex];
          return `${names[key]} / ${row.group}<br>${labels[1]}: ${valueText(row.lower, key)} \u2014 ${valueText(row.upper, key)}<br>${labels[4]}: ${valueText(row.entry_mean, key)}<br>${labels[5]}: ${number(row.starts)}<br>${labels[9]}: ${percent(row.breach_rate_pct)}`;
        }},
        xAxis: {type: 'category', data: rows.map(row => String(row.group)), name: labels[0], axisLabel: {color: color('--muted')}, axisLine: {lineStyle: {color: color('--rule')}}},
        yAxis: {type: 'value', name: labels[9] + ' (%)', axisLabel: {color: color('--muted')}, nameTextStyle: {color: color('--muted')}, splitLine: {lineStyle: {color: color('--rule')}}},
        series: [{type: 'bar', data: rows.map(row => row.breach_rate_pct), barMaxWidth: 48,
          label: {show: true, position: 'top', color: color('--ink'), formatter: item => item.value == null ? '' : item.value.toFixed(3) + '%'},
          markLine: {silent: true, symbol: 'none', lineStyle: {color: color('--accent2'), type: 'dashed'}, label: {position: 'insideEndTop', formatter: '\u6574\u4f53 ' + percent(rows[0].baseline_rate_pct), color: color('--accent2')}, data: [{yAxis: rows[0].baseline_rate_pct}]}
        }]
      }, true);
    });
  }
  ['side', 'layers'].forEach(id => document.getElementById(id).addEventListener('change', render));
  window.addEventListener('resize', () => Object.values(charts).forEach(chart => chart.resize()));
  render();
})();
