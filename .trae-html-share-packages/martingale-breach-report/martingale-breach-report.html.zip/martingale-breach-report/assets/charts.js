(function () {
  'use strict';
  const data = window.REPORT_DATA;
  const byId = (id) => document.getElementById(id);
  if (!data || !window.echarts) {
    byId('status').textContent = '本地数据或图表库未能加载，请确认 assets/data.js 与 _shared/js/echarts.min.js 完整。';
    return;
  }
  const style = getComputedStyle(document.documentElement);
  const theme = {};
  ['accent', 'accent2', 'ink', 'muted', 'rule', 'bg2', 'font'].forEach((key) => {
    theme[key] = style.getPropertyValue('--' + key).trim();
  });
  const number = (value, digits = 0) => value === null || value === undefined || !Number.isFinite(Number(value)) ? '—' : Number(value).toLocaleString('zh-CN', { maximumFractionDigits: digits, minimumFractionDigits: digits });
  const percent = (value) => number(value, 4) + (value === null || value === undefined ? '' : '%');
  const utc = (value, dayOnly = false) => {
    const date = new Date(value);
    if (!Number.isFinite(date.getTime())) return '—';
    return date.toISOString().slice(0, dayOnly ? 10 : 16).replace('T', ' ') + (dayOnly ? '' : ' UTC');
  };
  const escape = (value) => String(value).replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]));
  const direction = (side) => side === 'long' ? '做多' : '做空';
  const chart = echarts.init(byId('timeline'), null, { renderer: 'svg' });
  const bucketChart = echarts.init(byId('buckets'), null, { renderer: 'svg' });
  const calendarDimensions = {
    hour: { title: 'Daily start hour (UTC)', label: (key) => String(key).padStart(2, '0') + ':00' },
    weekday: { title: 'Weekly start day (UTC)', label: (key) => ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][key] },
    day_of_month: { title: 'Monthly start date (UTC)', label: (key) => 'Day ' + key },
    month: { title: 'Annual start month (UTC)', label: (key) => 'Month ' + key }
  };
  const calendarCharts = Object.fromEntries(Object.keys(calendarDimensions).map((key) => [key, echarts.init(byId('calendar-' + key), null, { renderer: 'svg' })]));
  const marketPrice = data.market.map((point) => [point[0], point[1]]);
  const marketVolatility = data.market.map((point) => [point[0], point[2]]);
  const minTime = new Date(data.meta.start).getTime();
  const maxTime = Math.max(data.market.length ? data.market[data.market.length - 1][0] : minTime, new Date(data.meta.end).getTime() || minTime);
  let zoom = { start: 0, end: 100 };
  const tooltip = {
    appendToBody: true,
    backgroundColor: theme.bg2,
    borderColor: theme.rule,
    textStyle: { color: theme.ink, fontFamily: theme.font, fontSize: 13 },
    extraCssText: 'max-width:320px;white-space:normal;line-height:1.7'
  };
  const axisStyle = { axisLabel: { color: theme.muted, fontSize: 11 }, axisLine: { lineStyle: { color: theme.rule } }, axisTick: { show: false }, splitLine: { lineStyle: { color: theme.rule } } };
  function timelineTooltip(params) {
    if (Array.isArray(params)) return params.map(timelineTooltip).filter(Boolean).join('<br>');
    const point = params.value;
    if (!Array.isArray(point)) return '';
    const heading = '<strong>' + escape(utc(point[0], params.seriesIndex === 4)) + '</strong><br>';
    if (params.seriesIndex === 1 || params.seriesIndex === 3) {
      return heading + escape(params.seriesName) + '<br>价格均值：' + number(point[1], 6) + '<br>年化波动率均值：' + percent(point[2]) + '<br>重合失败周期：' + number(point[3]);
    }
    if (params.seriesIndex === 4) return heading + '<br>失败周期：' + number(point[1]);
    return heading + escape(params.seriesName) + '：' + (params.seriesIndex === 2 ? percent(point[1]) : number(point[1], 6));
  }
  const rows = [...data.runs].sort((left, right) => (left.side === right.side ? left.layers - right.layers : left.side === 'long' ? -1 : 1));
  byId('runs-table').innerHTML = rows.map((run) => '<tr data-side="' + run.side + '" data-layers="' + run.layers + '"><td>' + direction(run.side) + ' / K' + run.layers + '</td><td>' + number(run.starts) + '</td><td>' + number(run.take_profit) + '</td><td>' + number(run.grid_stop) + '</td><td>' + number(run.unresolved) + '</td><td>' + percent(run.starts ? run.grid_stop / run.starts * 100 : null) + '</td><td>' + number(run.mean_net_pnl, 2) + '</td><td>' + percent(run.mean_net_return_pct * 100) + '</td><td>' + number(run.bars_held.mean, 1) + '</td></tr>').join('');
  byId('meta').textContent = utc(data.meta.start) + ' — ' + utc(data.meta.end) + ' · ' + number(data.meta.bars) + ' 根 5m K 线 · ' + number(data.market.length) + ' 个小时采样点';
  ['long', 'short'].forEach((side) => { byId('source-' + side).textContent = data.meta.sources[side]; });
  chart.on('datazoom', function () {
    const state = chart.getOption().dataZoom[0];
    zoom = { start: state.start, end: state.end };
  });
  function render() {
    const side = byId('side').value;
    const layers = Number(byId('layers').value);
    const mode = byId('mode').value;
    const run = data.runs.find((item) => item.side === side && item.layers === layers);
    if (!run) return;
    const events = run.events[mode];
    const eventName = mode === 'breach' ? '实际击穿事件' : '失败周期入场';
    const label = direction(side) + ' K' + layers;
    byId('starts').textContent = number(run.starts);
    byId('breaches').textContent = number(run.grid_stop);
    byId('rate').textContent = percent(run.starts ? run.grid_stop / run.starts * 100 : null);
    byId('unresolved').textContent = number(run.unresolved);
    byId('event-count').textContent = number(events.length) + ' 个独立事件时间戳';
    byId('event-label').textContent = eventName;
    byId('timeline-title').textContent = label + ' · 价格、信号波动率与每日' + (mode === 'breach' ? '击穿' : '失败起点') + '周期数';
    byId('mode-note').textContent = mode === 'breach' ? '当前标记最终触发网格止损的 5 分钟 K 线时点；波动率散点对应该时点上一根已收盘信号。' : '当前标记最终失败周期的入场时点；波动率散点对应入场时可获得的上一根已收盘信号。此为事后回溯，并非前瞻失败信号。';
    document.querySelectorAll('#runs-table tr').forEach((row) => row.classList.toggle('selected', row.dataset.side === side && Number(row.dataset.layers) === layers));
    const titles = ['价格 · 小时末采样', 'Annualized OHLC volatility · RS / EWMA ' + data.meta.volatilityEwmaSpan + ' / %', '每日失败周期数 · UTC'];
    const gridPositions = [54, 278, 492];
    const scatter = (axis) => ({
      name: eventName, type: 'scatter', xAxisIndex: axis, yAxisIndex: axis,
      data: axis === 1 ? events.filter((point) => point[2] !== null && Number.isFinite(point[2])) : events,
      encode: { x: 0, y: axis === 1 ? 2 : 1 },
      symbolSize: (point) => Math.min(12, 3 + Math.log2(1 + point[3]) * 1.1),
      itemStyle: { color: theme.accent2, opacity: 0.75 },
      label: { show: false }, emphasis: { scale: false }, progressive: 3000,
      tooltip: { trigger: 'item' }, z: 5
    });
    chart.setOption({
      animation: false, useUTC: true, color: [theme.accent, theme.accent2],
      textStyle: { fontFamily: theme.font, color: theme.ink },
      title: titles.map((text, index) => ({ text, left: 10, top: gridPositions[index] - 33, textStyle: { fontSize: 13, fontWeight: 600, color: theme.ink } })),
      tooltip: { ...tooltip, trigger: 'item', formatter: timelineTooltip },
      axisPointer: { link: [{ xAxisIndex: 'all' }], label: { backgroundColor: theme.accent } },
      grid: gridPositions.map((top, index) => ({ left: 70, right: 22, top, height: index === 2 ? 132 : 156 })),
      xAxis: gridPositions.map((_, index) => ({ ...axisStyle, type: 'time', gridIndex: index, min: minTime, max: maxTime, splitNumber: 5, splitLine: { show: false }, axisLabel: { color: theme.muted, fontSize: 11, hideOverlap: true, formatter: (value) => utc(value, true) }, axisPointer: { show: true } })),
      yAxis: gridPositions.map((_, index) => ({ ...axisStyle, type: 'value', gridIndex: index, scale: index !== 2, min: index === 2 ? 0 : undefined, minInterval: index === 2 ? 1 : undefined, axisLabel: { color: theme.muted, fontSize: 11, formatter: (value) => number(value, Math.abs(value) < 1 ? 1 : 0) } })),
      dataZoom: [{ type: 'inside', xAxisIndex: [0, 1, 2], filterMode: 'none', ...zoom }, { type: 'slider', xAxisIndex: [0, 1, 2], bottom: 24, height: 24, filterMode: 'none', ...zoom, borderColor: theme.rule, fillerColor: theme.accent + '22', handleStyle: { color: theme.accent }, textStyle: { color: theme.muted }, showDataShadow: false }],
      series: [
        { name: '价格', type: 'line', data: marketPrice, showSymbol: false, sampling: 'lttb', xAxisIndex: 0, yAxisIndex: 0, lineStyle: { color: theme.accent, width: 1 }, itemStyle: { color: theme.accent } },
        scatter(0),
        { name: '年化波动率', type: 'line', data: marketVolatility, showSymbol: false, connectNulls: false, sampling: 'lttb', xAxisIndex: 1, yAxisIndex: 1, lineStyle: { color: theme.accent, width: 1 }, itemStyle: { color: theme.accent } },
        scatter(1),
        { name: '每日失败周期数', type: 'bar', data: run.daily[mode], xAxisIndex: 2, yAxisIndex: 2, barMaxWidth: 12, itemStyle: { color: theme.accent2 } }
      ]
    }, { notMerge: true });
    const calendar = run.start_time_breakdown.groups;
    Object.entries(calendarDimensions).forEach(([key, dimension]) => {
      const groups = calendar[key];
      byId('calendar-' + key + '-title').textContent = label + ' · ' + dimension.title;
      calendarCharts[key].setOption({
        animation: false, color: [theme.accent2], textStyle: { fontFamily: theme.font, color: theme.ink },
        tooltip: { ...tooltip, trigger: 'item', formatter: (params) => {
          const group = groups[params.dataIndex];
          return '<strong>' + escape(dimension.label(group.key)) + '</strong><br>Starts: ' + number(group.starts) + '<br>Grid stops: ' + number(group.breaches) + '<br>Unresolved: ' + number(group.unresolved) + '<br>Breach rate: ' + percent(group.breach_rate === null ? null : group.breach_rate * 100) + '<br>Mean cycle return: ' + percent(group.mean_net_return === null ? null : group.mean_net_return * 100);
        } },
        grid: { left: 65, right: 20, top: 28, bottom: 65 },
        xAxis: { ...axisStyle, type: 'category', data: groups.map((group) => dimension.label(group.key)), axisLabel: { color: theme.muted, fontSize: 11, interval: 'auto', rotate: key === 'hour' || key === 'day_of_month' ? 40 : 0 }, splitLine: { show: false } },
        yAxis: { ...axisStyle, type: 'value', min: 0, name: 'Breach rate / %', nameTextStyle: { color: theme.muted }, axisLabel: { color: theme.muted, formatter: '{value}%' } },
        series: [{ name: 'Breach rate', type: 'bar', barMaxWidth: 40, data: groups.map((group) => group.breach_rate === null ? null : group.breach_rate * 100), itemStyle: { color: theme.accent2 } }]
      }, { notMerge: true });
    });
    const dimensionKey = byId('calendar-dimension').value;
    const dimension = calendarDimensions[dimensionKey];
    byId('calendar-caption').textContent = label + ' · ' + dimension.title;
    byId('calendar-table').innerHTML = calendar[dimensionKey].map((group) => '<tr><td>' + escape(dimension.label(group.key)) + '</td><td>' + number(group.starts) + '</td><td>' + number(group.take_profit) + '</td><td>' + number(group.breaches) + '</td><td>' + number(group.unresolved) + '</td><td>' + percent(group.breach_rate === null ? null : group.breach_rate * 100) + '</td><td>' + number(group.mean_net_pnl, 2) + '</td><td>' + percent(group.mean_net_return === null ? null : group.mean_net_return * 100) + '</td><td>' + number(group.mean_bars_held, 1) + '</td></tr>').join('');
    renderBuckets();
  }
  function renderBuckets() {
    const side = byId('side').value;
    const layers = Number(byId('layers').value);
    const span = byId('bucket-span').value;
    const run = data.runs.find((item) => item.side === side && item.layers === layers);
    const label = direction(side) + ' K' + layers + ' / EWMA ' + span;
    const buckets = run.buckets_by_span[span];
    const bucketStarts = buckets.reduce((sum, bucket) => sum + bucket.starts, 0);
    byId('bucket-chart-title').textContent = label + ' · Breach rate and market share by entry volatility';
    byId('bucket-note').textContent = 'Bins are left-inclusive and right-exclusive. Market share = full-resolution 5m bars in each bin / all ' + number(data.meta.bars) + ' market bars. Warmup bars: ' + number(data.meta.marketWarmupBars) + '. Binned starts: ' + number(bucketStarts) + '; excluded starts: ' + number(run.starts - bucketStarts) + '. Unequal bin widths mean shares are frequency mass, not density. Drag the slider to inspect narrow bins.';
    bucketChart.setOption({
      animation: false, color: [theme.accent2, theme.accent], textStyle: { fontFamily: theme.font, color: theme.ink },
      legend: { top: 0, textStyle: { color: theme.ink }, data: ['Conditional breach rate', 'Share of all market bars'] },
      tooltip: { ...tooltip, trigger: 'axis', formatter: (params) => {
        const bucket = buckets[params[0].dataIndex];
        return '<strong>Annualized entry volatility ' + escape(bucket.label) + '</strong><br>Starts: ' + number(bucket.starts) + '<br>Breaches: ' + number(bucket.breaches) + '<br>Conditional breach rate: ' + percent(bucket.rate) + '<br>Market bars: ' + number(bucket.market_bars) + '<br>Share of all market bars: ' + percent(bucket.market_share);
      } },
      grid: { left: 62, right: 72, top: 65, bottom: 100 },
      xAxis: { ...axisStyle, type: 'category', data: buckets.map((bucket) => bucket.label), axisLabel: { color: theme.muted, fontSize: 10, interval: 0, rotate: 45 }, splitLine: { show: false } },
      yAxis: [
        { ...axisStyle, type: 'value', name: 'Breach / %', nameTextStyle: { color: theme.accent2 }, min: 0, axisLabel: { color: theme.muted, formatter: '{value}%' } },
        { ...axisStyle, type: 'value', name: 'Market share / %', nameTextStyle: { color: theme.accent }, min: 0, splitLine: { show: false }, axisLabel: { color: theme.muted, formatter: '{value}%' } }
      ],
      dataZoom: [{ type: 'slider', bottom: 8, height: 20, start: 0, end: 100, showDataShadow: false }],
      series: [
        { name: 'Conditional breach rate', type: 'bar', yAxisIndex: 0, barMaxWidth: 36, data: buckets.map((bucket) => bucket.rate), itemStyle: { color: theme.accent2, borderRadius: [4, 4, 0, 0] } },
        { name: 'Share of all market bars', type: 'line', yAxisIndex: 1, data: buckets.map((bucket) => bucket.market_share), smooth: false, symbolSize: 5, lineStyle: { color: theme.accent, width: 2 }, itemStyle: { color: theme.accent }, z: 5 }
      ]
    }, { notMerge: true });
  }
  byId('bucket-span').addEventListener('change', renderBuckets);
  ['side', 'layers', 'mode', 'calendar-dimension'].forEach((id) => byId(id).addEventListener('change', render));
  byId('reset').addEventListener('click', () => {
    zoom = { start: 0, end: 100 };
    chart.dispatchAction({ type: 'dataZoom', start: 0, end: 100 });
  });
  window.addEventListener('resize', () => { chart.resize(); bucketChart.resize(); Object.values(calendarCharts).forEach((item) => item.resize()); });
  render();
})();
