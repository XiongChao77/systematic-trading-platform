(function () {
  'use strict';
  const button = document.getElementById('backtest');
  const status = document.getElementById('backtest-status');
  const controls = ['side', 'layers', 'mode', 'calendar-dimension'];
  let activeId = null;
  let timer;
  const restored = sessionStorage.getItem('scan-report-controls');
  if (restored) {
    sessionStorage.removeItem('scan-report-controls');
    const values = JSON.parse(restored);
    controls.forEach((id) => { document.getElementById(id).value = values[id]; });
    document.getElementById('side').dispatchEvent(new Event('change'));
  }
  function offline() {
    button.disabled = true;
    status.textContent = 'Local scan service unavailable. Run: python experiment/martingale_report.py, then open http://127.0.0.1:8876/';
  }
  async function request(method) {
    const response = await fetch('/api/backtest', { method, cache: 'no-store' });
    if (!response.ok && response.status !== 409) throw new Error('Service returned HTTP ' + response.status);
    return response.json();
  }
  function show(state) {
    button.disabled = state.status === 'running';
    button.textContent = state.status === 'running' ? 'Running…' : '\u56de\u6d4b';
    status.textContent = state.message;
    if (state.status === 'running') activeId = state.id;
    if (state.status === 'completed' && activeId === state.id) {
      sessionStorage.setItem('scan-report-controls', JSON.stringify(Object.fromEntries(controls.map((id) => [id, document.getElementById(id).value]))));
      window.location.reload();
      return;
    }
    if (state.status === 'running') timer = setTimeout(poll, 1500);
  }
  async function poll() {
    try { show(await request('GET')); }
    catch (error) {
      button.disabled = true;
      status.textContent = 'Connection lost; reconnecting. ' + error.message;
      timer = setTimeout(poll, 3000);
    }
  }
  button.addEventListener('click', async () => {
    clearTimeout(timer);
    button.disabled = true;
    status.textContent = 'Starting long and short scans, K2–K6…';
    try { show(await request('POST')); }
    catch (error) { button.disabled = false; status.textContent = 'Could not start scan: ' + error.message; }
  });
  if (!['http:', 'https:'].includes(window.location.protocol)) offline();
  else request('GET').then(show).catch(offline);
})();
